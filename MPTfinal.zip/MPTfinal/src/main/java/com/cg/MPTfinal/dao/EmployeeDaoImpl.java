package com.cg.MPTfinal.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	MongoTemplate mt;
	@Override
	public List<Employee> readData() {
		// TODO Auto-generated method stub
		return mt.findAll(Employee.class);
	}

	@Override
	public void insertData(Employee e) {
		// TODO Auto-generated method stub
          mt.insert(e);
	}

	@Override
	public Employee updateEmployee(int id, String name) {
		// TODO Auto-generated method stub
		 Query query=new Query();
		 query.addCriteria(Criteria.where("id").is(id));
		 Update update=new Update();
		 update.set("name", name);
		 mt.updateFirst(query, update, Employee.class);
		 return mt.findById(id, Employee.class);
	}

	@Override
	public Employee readoneEmployee(int id) {
		// TODO Auto-generated method stub
		return mt.findById(id, Employee.class);
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		 Query query=new Query();
		 query.addCriteria(Criteria.where("id").is(id));
		 mt.remove(query, Employee.class);
		
	}


}
