package com.cg.MPTfinal.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.cg.MPTfinal.dao.Employee;
import com.cg.MPTfinal.exception.EmployeeNotFoundException;

public interface EmployeeService {

	
	public List<Employee> readData();
	public void insertData(@RequestBody Employee e);
	
	public Employee updateEmployee(int id, String name);
	public Employee readoneEmployee(int id) throws EmployeeNotFoundException;
	public void deleteEmployee(int id);
}
