package com.cg.MPTfinal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.MPTfinal.dao.Employee;
import com.cg.MPTfinal.dao.EmployeeDao;
import com.cg.MPTfinal.exception.EmployeeNotFoundException;


@Service
public class EmployeeServiceImpl implements EmployeeService {
 
	@Autowired
	EmployeeDao daoob;
	@Override
	public List<Employee> readData()  {
		// TODO Auto-generated method stub
		return daoob.readData();
	}

	@Override
	public void insertData(Employee e) {
		// TODO Auto-generated method stub
		daoob.insertData(e);
	}

	@Override
	public Employee updateEmployee(int id, String name) {
		// TODO Auto-generated method stub
		return daoob.updateEmployee(id,name);
	}

	@Override
	public Employee readoneEmployee(int id) throws EmployeeNotFoundException {
		Employee e = daoob.readoneEmployee(id);
		if (e == null) {
			throw new EmployeeNotFoundException("NOT FOUND");
		}
		return e;
		
		// return daoob.readoneEmployee(id);
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		daoob.deleteEmployee(id);
	}

}
