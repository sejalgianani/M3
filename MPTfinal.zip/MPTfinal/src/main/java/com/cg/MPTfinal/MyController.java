package com.cg.MPTfinal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.MPTfinal.dao.Employee;
import com.cg.MPTfinal.exception.EmployeeNotFoundException;
import com.cg.MPTfinal.service.EmployeeService;

@RestController
public class MyController {

	@Autowired
	EmployeeService es;

	// Read All Employee
	@GetMapping(path = "/read")
	public List<Employee> readData() {
		return es.readData();
	}

	// Read one Employee by id
	@GetMapping("/readone/{id}")
	public Employee readoneEmployee(@PathVariable("id") int id) throws EmployeeNotFoundException {
		return es.readoneEmployee(id);
	
	}
	//Insert Employee
	@PostMapping(path = "/insert")
	public String insertData(@RequestBody Employee e) {
		es.insertData(e);
		return "SUCCESS";
	}

	// Update Employee
	@PutMapping("/update/{id}/{name}")
	public Employee updateEmployee(@PathVariable("id") int id, @PathVariable("name") String name) {
		return es.updateEmployee(id, name);

	}
	
	//Delete by ID
	
	@PostMapping("/deletebyid/{id}")
	public String deleteEmployee(@PathVariable("id") int id) {
		es.deleteEmployee(id);
	 return "deleted";
	}

}
