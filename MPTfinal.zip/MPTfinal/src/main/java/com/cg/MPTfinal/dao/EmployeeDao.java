package com.cg.MPTfinal.dao;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

public interface EmployeeDao {

	public List<Employee> readData();

	public void insertData(@RequestBody Employee e);
	
	public Employee updateEmployee(int id, String name);

	public Employee readoneEmployee(int id);

	public void deleteEmployee(int id);

}
